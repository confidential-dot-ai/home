{{/*
Image reference with digest support.
Usage: {{ include "c8s-common.image" .Values.image }}
Renders repo@digest when .digest is set, otherwise repo:tag. Charts must
not pin a default tag — the consumer (HelmRelease values or cluster
overlay) is responsible for supplying image.tag or image.digest. The
helper fails loudly if neither is provided.
*/}}
{{- define "c8s-common.image" -}}
{{- $img := . -}}
{{- if $img.digest -}}
{{ $img.repository }}@{{ $img.digest }}
{{- else -}}
{{ $img.repository }}:{{ required (printf "image.tag or image.digest is required for %s" $img.repository) $img.tag }}
{{- end -}}
{{- end }}
